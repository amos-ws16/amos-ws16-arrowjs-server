#!/bin/bash
cd /home/ubuntu/amos-dev
npm install
