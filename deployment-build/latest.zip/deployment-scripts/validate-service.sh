#!/bin/bash
echo "validate that amos app is working..."
