#!/bin/bash
echo "execute before installing amos app"
rm -R /home/ubuntu/amos-dev/node_modules
